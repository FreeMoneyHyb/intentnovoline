package com.viaversion.viabackwards.api.rewriters;

// $FF: synthetic class
class LegacyBlockItemRewriter$1 {
}
