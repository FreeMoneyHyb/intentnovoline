package com.viaversion.viabackwards.api.exceptions;

import com.viaversion.viabackwards.api.exceptions.RemovedValueException$1;
import java.io.IOException;

public class RemovedValueException extends IOException {
   public static final RemovedValueException EX = new RemovedValueException$1();
}
