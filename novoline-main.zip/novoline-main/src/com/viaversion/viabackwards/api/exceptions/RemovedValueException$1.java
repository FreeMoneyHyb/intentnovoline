package com.viaversion.viabackwards.api.exceptions;

import com.viaversion.viabackwards.api.exceptions.RemovedValueException;

final class RemovedValueException$1 extends RemovedValueException {
   public Throwable fillInStackTrace() {
      return this;
   }
}
