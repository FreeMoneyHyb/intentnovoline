package cc.novoline.events.events;

import cc.novoline.events.events.Event;

public class PlayerUpdateEvent implements Event {
}
