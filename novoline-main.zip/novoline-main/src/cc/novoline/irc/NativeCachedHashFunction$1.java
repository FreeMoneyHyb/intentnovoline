package cc.novoline.irc;

// $FF: synthetic class
class NativeCachedHashFunction$1 {
}
