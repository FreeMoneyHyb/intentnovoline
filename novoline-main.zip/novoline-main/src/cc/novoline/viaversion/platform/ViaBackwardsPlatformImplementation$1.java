package cc.novoline.viaversion.platform;

import cc.novoline.viaversion.platform.ViaBackwardsPlatformImplementation;
import viaversion.viabackwards.api.ViaBackwardsConfig;

class ViaBackwardsPlatformImplementation$1 implements ViaBackwardsConfig {
   final ViaBackwardsPlatformImplementation this$0;

   ViaBackwardsPlatformImplementation$1(ViaBackwardsPlatformImplementation var1) {
      this.this$0 = var1;
   }

   public boolean addCustomEnchantsToLore() {
      return true;
   }

   public boolean addTeamColorTo1_13Prefix() {
      return true;
   }

   public boolean isFix1_13FacePlayer() {
      return true;
   }

   public boolean alwaysShowOriginalMobName() {
      return true;
   }
}
