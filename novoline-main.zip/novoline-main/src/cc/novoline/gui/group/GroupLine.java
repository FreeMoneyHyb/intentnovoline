package cc.novoline.gui.group;

public interface GroupLine {
   String getText(Object var1);
}
