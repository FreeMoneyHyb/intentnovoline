package cc.novoline.gui.group2;

import cc.novoline.gui.group2.AbstractRoundedGroupWithTitle;
import cc.novoline.gui.label.Label;

public final class BasicRoundedGroupWithTitle extends AbstractRoundedGroupWithTitle {
   public BasicRoundedGroupWithTitle(Label var1, int var2, int var3, int var4, int var5, int var6) {
      super(var1, var2, -1996488705, var3, var4, var5, var6);
   }
}
