package cc.novoline.gui.group2;

import cc.novoline.gui.group2.Group;

public interface RoundedGroup extends Group {
   int getRadius();

   void setRadius(int var1);
}
