package cc.novoline.gui.group2;

import cc.novoline.gui.group2.GroupWithTitle;
import cc.novoline.gui.group2.RoundedGroup;

public interface RoundedGroupWithTitle extends RoundedGroup, GroupWithTitle {
}
