package cc.novoline.modules;

import cc.novoline.modules.EnumModuleType;

// $FF: synthetic class
class AbstractModule$1 {
   static final int[] $SwitchMap$cc$novoline$modules$EnumModuleType = new int[EnumModuleType.values().length];

   static {
      try {
         $SwitchMap$cc$novoline$modules$EnumModuleType[EnumModuleType.COMBAT.ordinal()] = 1;
      } catch (NoSuchFieldError var4) {
         ;
      }

      try {
         $SwitchMap$cc$novoline$modules$EnumModuleType[EnumModuleType.MOVEMENT.ordinal()] = 2;
      } catch (NoSuchFieldError var3) {
         ;
      }

      try {
         $SwitchMap$cc$novoline$modules$EnumModuleType[EnumModuleType.VISUALS.ordinal()] = 3;
      } catch (NoSuchFieldError var2) {
         ;
      }

      try {
         $SwitchMap$cc$novoline$modules$EnumModuleType[EnumModuleType.PLAYER.ordinal()] = 4;
      } catch (NoSuchFieldError var1) {
         ;
      }

   }
}
