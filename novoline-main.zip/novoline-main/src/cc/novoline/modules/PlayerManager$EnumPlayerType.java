package cc.novoline.modules;

public enum PlayerManager$EnumPlayerType {
   FRIEND,
   TARGET;

   private static final PlayerManager$EnumPlayerType[] $VALUES = new PlayerManager$EnumPlayerType[]{FRIEND, TARGET};
}
