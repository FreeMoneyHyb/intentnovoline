package cc.novoline.modules.configurations.property.object;

// $FF: synthetic class
class BooleanProperty$1 {
}
