package cc.novoline.modules.configurations;

import cc.novoline.modules.configurations.ConfigManager;
import com.google.common.reflect.TypeToken;

class ConfigManager$1 extends TypeToken {
   final ConfigManager this$0;

   ConfigManager$1(ConfigManager var1) {
      this.this$0 = var1;
   }
}
