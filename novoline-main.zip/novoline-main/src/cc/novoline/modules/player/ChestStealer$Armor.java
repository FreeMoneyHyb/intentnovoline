package cc.novoline.modules.player;

public enum ChestStealer$Armor {
   CHESTPLATE,
   LEGGINS,
   HELMET,
   BOOTS;

   private static final ChestStealer$Armor[] $VALUES = new ChestStealer$Armor[]{CHESTPLATE, LEGGINS, HELMET, BOOTS};
}
