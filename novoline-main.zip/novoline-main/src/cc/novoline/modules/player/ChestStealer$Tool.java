package cc.novoline.modules.player;

public enum ChestStealer$Tool {
   PICKAXE,
   SHOVEL,
   AXE;

   private static final ChestStealer$Tool[] $VALUES = new ChestStealer$Tool[]{PICKAXE, SHOVEL, AXE};
}
