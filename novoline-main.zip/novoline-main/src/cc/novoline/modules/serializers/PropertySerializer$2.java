package cc.novoline.modules.serializers;

import ninja.leaping.configurate.ValueType;

// $FF: synthetic class
class PropertySerializer$2 {
   static final int[] $SwitchMap$ninja$leaping$configurate$ValueType = new int[ValueType.values().length];

   static {
      try {
         $SwitchMap$ninja$leaping$configurate$ValueType[ValueType.LIST.ordinal()] = 1;
      } catch (NoSuchFieldError var3) {
         ;
      }

      try {
         $SwitchMap$ninja$leaping$configurate$ValueType[ValueType.SCALAR.ordinal()] = 2;
      } catch (NoSuchFieldError var2) {
         ;
      }

      try {
         $SwitchMap$ninja$leaping$configurate$ValueType[ValueType.MAP.ordinal()] = 3;
      } catch (NoSuchFieldError var1) {
         ;
      }

   }
}
