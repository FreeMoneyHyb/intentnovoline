package cc.novoline.modules.serializers;

import cc.novoline.modules.serializers.PropertySerializer;
import com.google.common.reflect.TypeToken;

class PropertySerializer$1 extends TypeToken {
   final PropertySerializer this$0;

   PropertySerializer$1(PropertySerializer var1) {
      this.this$0 = var1;
   }
}
