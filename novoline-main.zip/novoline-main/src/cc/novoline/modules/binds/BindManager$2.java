package cc.novoline.modules.binds;

import cc.novoline.modules.binds.BindManager;
import com.google.common.reflect.TypeToken;

class BindManager$2 extends TypeToken {
   final BindManager this$0;

   BindManager$2(BindManager var1) {
      this.this$0 = var1;
   }
}
