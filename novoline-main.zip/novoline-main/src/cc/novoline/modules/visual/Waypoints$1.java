package cc.novoline.modules.visual;

import cc.novoline.modules.visual.Waypoints;
import com.google.common.reflect.TypeToken;

class Waypoints$1 extends TypeToken {
   final Waypoints this$0;

   Waypoints$1(Waypoints var1) {
      this.this$0 = var1;
   }
}
