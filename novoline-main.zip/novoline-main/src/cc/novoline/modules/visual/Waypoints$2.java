package cc.novoline.modules.visual;

import cc.novoline.modules.visual.Waypoints;
import com.google.common.reflect.TypeToken;

class Waypoints$2 extends TypeToken {
   final Waypoints this$0;

   Waypoints$2(Waypoints var1) {
      this.this$0 = var1;
   }
}
