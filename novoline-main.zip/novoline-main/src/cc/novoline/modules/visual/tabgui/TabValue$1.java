package cc.novoline.modules.visual.tabgui;

import cc.novoline.gui.screen.setting.SettingType;

// $FF: synthetic class
class TabValue$1 {
   static final int[] $SwitchMap$cc$novoline$gui$screen$setting$SettingType = new int[SettingType.values().length];

   static {
      try {
         $SwitchMap$cc$novoline$gui$screen$setting$SettingType[SettingType.SLIDER.ordinal()] = 1;
      } catch (NoSuchFieldError var3) {
         ;
      }

      try {
         $SwitchMap$cc$novoline$gui$screen$setting$SettingType[SettingType.COMBOBOX.ordinal()] = 2;
      } catch (NoSuchFieldError var2) {
         ;
      }

      try {
         $SwitchMap$cc$novoline$gui$screen$setting$SettingType[SettingType.SELECTBOX.ordinal()] = 3;
      } catch (NoSuchFieldError var1) {
         ;
      }

   }
}
