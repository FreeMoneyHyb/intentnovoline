package cc.novoline.utils.music;

public interface IMusicPlayer {
   void setup(String var1) throws Throwable;

   void play();

   void stop();

   void playLooping();
}
