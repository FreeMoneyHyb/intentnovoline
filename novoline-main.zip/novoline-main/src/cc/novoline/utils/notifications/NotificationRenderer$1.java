package cc.novoline.utils.notifications;

import cc.novoline.utils.notifications.NotificationType;

// $FF: synthetic class
class NotificationRenderer$1 {
   static final int[] $SwitchMap$cc$novoline$utils$notifications$NotificationType = new int[NotificationType.values().length];

   static {
      try {
         $SwitchMap$cc$novoline$utils$notifications$NotificationType[NotificationType.ERROR.ordinal()] = 1;
      } catch (NoSuchFieldError var4) {
         ;
      }

      try {
         $SwitchMap$cc$novoline$utils$notifications$NotificationType[NotificationType.WARNING.ordinal()] = 2;
      } catch (NoSuchFieldError var3) {
         ;
      }

      try {
         $SwitchMap$cc$novoline$utils$notifications$NotificationType[NotificationType.SUCCESS.ordinal()] = 3;
      } catch (NoSuchFieldError var2) {
         ;
      }

      try {
         $SwitchMap$cc$novoline$utils$notifications$NotificationType[NotificationType.INFO.ordinal()] = 4;
      } catch (NoSuchFieldError var1) {
         ;
      }

   }
}
