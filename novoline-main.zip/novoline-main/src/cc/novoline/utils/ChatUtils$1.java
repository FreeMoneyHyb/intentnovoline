package cc.novoline.utils;

// $FF: synthetic class
class ChatUtils$1 {
}
