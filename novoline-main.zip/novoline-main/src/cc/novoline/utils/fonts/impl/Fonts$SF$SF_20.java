package cc.novoline.utils.fonts.impl;

import cc.novoline.utils.fonts.api.FontRenderer;
import cc.novoline.utils.fonts.impl.Fonts$SF;

public final class Fonts$SF$SF_20 {
   public static final FontRenderer SF_20 = Fonts$SF.SF.ofSize(20);
}
