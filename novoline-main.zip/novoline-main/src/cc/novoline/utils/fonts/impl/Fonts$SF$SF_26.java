package cc.novoline.utils.fonts.impl;

import cc.novoline.utils.fonts.api.FontRenderer;
import cc.novoline.utils.fonts.impl.Fonts$SF;

public final class Fonts$SF$SF_26 {
   public static final FontRenderer SF_26 = Fonts$SF.SF.ofSize(26);
}
