package cc.novoline.utils.fonts.impl;

import cc.novoline.utils.fonts.api.FontRenderer;
import cc.novoline.utils.fonts.impl.Fonts$SFTHIN;

public final class Fonts$SFTHIN$SFTHIN_10 {
   public static final FontRenderer SFTHIN_10 = Fonts$SFTHIN.SFTHIN.ofSize(10);
}
