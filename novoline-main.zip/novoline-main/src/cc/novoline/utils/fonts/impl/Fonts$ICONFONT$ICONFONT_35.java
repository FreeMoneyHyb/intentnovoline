package cc.novoline.utils.fonts.impl;

import cc.novoline.utils.fonts.api.FontRenderer;
import cc.novoline.utils.fonts.impl.Fonts$ICONFONT;

public final class Fonts$ICONFONT$ICONFONT_35 {
   public static final FontRenderer ICONFONT_35 = Fonts$ICONFONT.ICONFONT.ofSize(35);
}
