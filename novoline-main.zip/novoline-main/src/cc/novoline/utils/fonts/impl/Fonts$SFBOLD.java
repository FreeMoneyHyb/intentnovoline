package cc.novoline.utils.fonts.impl;

import cc.novoline.utils.fonts.api.FontFamily;
import cc.novoline.utils.fonts.api.FontType;
import cc.novoline.utils.fonts.impl.Fonts;

public interface Fonts$SFBOLD {
   FontFamily SFBOLD = Fonts.FONT_MANAGER.fontFamily(FontType.SFBOLD);
}
