package cc.novoline.utils.fonts.impl;

import cc.novoline.utils.fonts.api.FontRenderer;
import cc.novoline.utils.fonts.impl.Fonts$ICONFONT;

public final class Fonts$ICONFONT$ICONFONT_24 {
   public static final FontRenderer ICONFONT_24 = Fonts$ICONFONT.ICONFONT.ofSize(24);
}
