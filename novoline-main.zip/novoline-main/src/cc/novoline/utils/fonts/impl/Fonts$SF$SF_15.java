package cc.novoline.utils.fonts.impl;

import cc.novoline.utils.fonts.api.FontRenderer;
import cc.novoline.utils.fonts.impl.Fonts$SF;

public final class Fonts$SF$SF_15 {
   public static final FontRenderer SF_15 = Fonts$SF.SF.ofSize(15);
}
