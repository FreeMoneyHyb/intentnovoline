package cc.novoline.utils.fonts.impl;

import cc.novoline.utils.fonts.api.FontRenderer;
import cc.novoline.utils.fonts.impl.Fonts$OXIDE;

public final class Fonts$OXIDE$OXIDE_55 {
   public static final FontRenderer OXIDE_55 = Fonts$OXIDE.OXIDE.ofSize(40);
}
