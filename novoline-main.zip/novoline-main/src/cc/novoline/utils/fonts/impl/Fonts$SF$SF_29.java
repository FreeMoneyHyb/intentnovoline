package cc.novoline.utils.fonts.impl;

import cc.novoline.utils.fonts.api.FontRenderer;
import cc.novoline.utils.fonts.impl.Fonts$SF;

public final class Fonts$SF$SF_29 {
   public static final FontRenderer SF_29 = Fonts$SF.SF.ofSize(29);
}
