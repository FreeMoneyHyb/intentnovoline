package cc.novoline.commands.impl;

import cc.novoline.commands.impl.NameCommand;
import com.google.gson.reflect.TypeToken;

class NameCommand$1 extends TypeToken {
   final NameCommand this$0;

   NameCommand$1(NameCommand var1) {
      this.this$0 = var1;
   }
}
