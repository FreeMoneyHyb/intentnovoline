package cc.novoline.commands.impl;

import cc.novoline.modules.PlayerManager$EnumPlayerType;

// $FF: synthetic class
class TargetCommand$1 {
   static final int[] $SwitchMap$cc$novoline$modules$PlayerManager$EnumPlayerType = new int[PlayerManager$EnumPlayerType.values().length];

   static {
      try {
         $SwitchMap$cc$novoline$modules$PlayerManager$EnumPlayerType[PlayerManager$EnumPlayerType.FRIEND.ordinal()] = 1;
      } catch (NoSuchFieldError var2) {
         ;
      }

      try {
         $SwitchMap$cc$novoline$modules$PlayerManager$EnumPlayerType[PlayerManager$EnumPlayerType.TARGET.ordinal()] = 2;
      } catch (NoSuchFieldError var1) {
         ;
      }

   }
}
